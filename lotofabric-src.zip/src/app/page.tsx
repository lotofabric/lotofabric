import { useTranslations } from "next-intl";

export default function Home() {
  const t = useTranslations("home");

  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-neutral-900 text-white py-24 px-6 text-center">
        <h1 className="text-5xl font-bold mb-4">{t("hero.title")}</h1>
        <p className="text-lg text-neutral-300 mb-8">{t("hero.subtitle")}</p>
        <a
          href="/shop"
          className="inline-block bg-white text-neutral-900 font-semibold px-8 py-3 rounded-full hover:bg-neutral-200 transition"
        >
          {t("hero.cta")}
        </a>
      </section>

      {/* Features Section */}
      <section className="py-16 px-6 max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
        <div className="p-6 border rounded-xl">
          <div className="text-3xl mb-3">🧵</div>
          <h3 className="font-semibold text-lg mb-2">{t("features.quality.title")}</h3>
          <p className="text-neutral-500 text-sm">{t("features.quality.description")}</p>
        </div>
        <div className="p-6 border rounded-xl">
          <div className="text-3xl mb-3">🚚</div>
          <h3 className="font-semibold text-lg mb-2">{t("features.shipping.title")}</h3>
          <p className="text-neutral-500 text-sm">{t("features.shipping.description")}</p>
        </div>
        <div className="p-6 border rounded-xl">
          <div className="text-3xl mb-3">🎨</div>
          <h3 className="font-semibold text-lg mb-2">{t("features.variety.title")}</h3>
          <p className="text-neutral-500 text-sm">{t("features.variety.description")}</p>
        </div>
      </section>
    </main>
  );
}
